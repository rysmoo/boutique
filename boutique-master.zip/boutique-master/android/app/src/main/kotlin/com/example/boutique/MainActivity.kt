package com.example.boutique

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
